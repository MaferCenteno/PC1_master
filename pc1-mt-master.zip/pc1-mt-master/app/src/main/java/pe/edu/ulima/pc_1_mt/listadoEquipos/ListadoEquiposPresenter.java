package pe.edu.ulima.pc_1_mt.listadoEquipos;

/**
 * Created by Stefanny on 16/05/2016.
 */
public interface ListadoEquiposPresenter {

    public void obtenerEquipos();
}
