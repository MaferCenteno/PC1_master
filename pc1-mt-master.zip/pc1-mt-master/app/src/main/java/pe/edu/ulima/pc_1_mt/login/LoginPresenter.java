package pe.edu.ulima.pc_1_mt.login;

import bean.Alumno;

/**
 * Created by Stefanny on 15/05/2016.
 */
public interface LoginPresenter {

    public void obtenerLogin(Alumno alumno);


}
